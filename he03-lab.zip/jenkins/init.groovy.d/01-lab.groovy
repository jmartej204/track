import com.cloudbees.plugins.credentials.CredentialsScope
import com.cloudbees.plugins.credentials.SystemCredentialsProvider
import hudson.model.Item
import hudson.security.GlobalMatrixAuthorizationStrategy
import hudson.security.HudsonPrivateSecurityRealm
import jenkins.model.Jenkins
import com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPrivateKey
import org.jenkinsci.plugins.plaincredentials.impl.StringCredentialsImpl
import org.jenkinsci.plugins.workflow.cps.CpsFlowDefinition
import org.jenkinsci.plugins.workflow.job.WorkflowJob
import hudson.util.Secret

def jenkins = Jenkins.get()

def ciFlag = new File(jenkins.rootDir, 'lab-flags/ci.txt')
ciFlag.parentFile.mkdirs()
if (!ciFlag.exists()) {
    ciFlag.text = 'HE03{ci_compromised}\n'
    ciFlag.setReadable(true, true)
    ciFlag.setWritable(false, false)
}

def realm = new HudsonPrivateSecurityRealm(false)
realm.createAccount('admin', 'InstructorOnly!2026')
realm.createAccount('developer', 'Developer!2026')
jenkins.setSecurityRealm(realm)

def authorization = new GlobalMatrixAuthorizationStrategy()
authorization.add(Jenkins.ADMINISTER, 'admin')
authorization.add(Jenkins.READ, 'developer')
authorization.add(Item.READ, 'developer')
authorization.add(Item.BUILD, 'developer')
authorization.add(Item.WORKSPACE, 'developer')
authorization.add(Item.DISCOVER, 'developer')
jenkins.setAuthorizationStrategy(authorization)

def privateKey = '''-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACAD7ffw2YN0DCusTaJhHesDCp84My2KdZmCmCICNWurfQAAAJAc51mOHOdZ
jgAAAAtzc2gtZWQyNTUxOQAAACAD7ffw2YN0DCusTaJhHesDCp84My2KdZmCmCICNWurfQ
AAAEDSUfqDu9eNZJeer36nNYiHMNrQdLJXbKb/c2Xh7duyVwPt9/DZg3QMK6xNomEd6wMK
nzgzLYp1mYKYIgI1a6t9AAAACXByb2ZAcHJvZgECAwQ=
-----END OPENSSH PRIVATE KEY-----'''

def credentialStore = SystemCredentialsProvider.getInstance()
if (!credentialStore.getCredentials().any { it.id == 'ci-runner-ssh' }) {
    def credentials = new BasicSSHUserPrivateKey(
        CredentialsScope.GLOBAL,
        'ci-runner-ssh',
        'ci-runner',
        new BasicSSHUserPrivateKey.DirectEntryPrivateKeySource(privateKey),
        '',
        'HE03 simulated deployment key'
    )
    credentialStore.getCredentials().add(credentials)
    credentialStore.save()
}

def simulatedTokens = [
    'he03-npm-token': ['HE03 simulated NPM registry token', 'he03_npm_7f9c2a1e4d8b'],
    'he03-deploy-token': ['HE03 simulated deployment token', 'he03_deploy_3b6e8f0a9c2d']
]
simulatedTokens.each { credentialId, values ->
    if (!credentialStore.getCredentials().any { it.id == credentialId }) {
        credentialStore.getCredentials().add(new StringCredentialsImpl(
            CredentialsScope.GLOBAL,
            credentialId,
            values[0],
            Secret.fromString(values[1])
        ))
        credentialStore.save()
    }
}

// API token for the API build path. The password-based crumb does not validate
// against recent Jenkins LTS releases, so the exercise uses this token instead.
def fixedApiTokenValue = '11e03b0dd71b4f0a98c9d3f5c4a2e1b7d6'
def apiTokenFile = new File(jenkins.rootDir, 'lab-dev-api-token.txt')
if (!apiTokenFile.exists() || apiTokenFile.text.trim() != fixedApiTokenValue) {
    def devUser = hudson.model.User.getOrCreateByIdOrFullName('developer')
    if (devUser != null) {
        def tokenProperty = devUser.getProperty(jenkins.security.ApiTokenProperty.class)
        if (tokenProperty == null) {
            tokenProperty = new jenkins.security.ApiTokenProperty()
            devUser.addProperty(tokenProperty)
        }
        if (!tokenProperty.getTokenList().any { it.name == 'he03-dev-api' }) {
            tokenProperty.addFixedNewToken('he03-dev-api', fixedApiTokenValue)
        }
        apiTokenFile.text = fixedApiTokenValue+'\n'
        apiTokenFile.setReadable(true, false)
        apiTokenFile.setWritable(false, false)
        devUser.save()
    }
}


def pipeline = '''pipeline {
  agent any
  stages {
    stage('Checkout') {
      steps {
        sh 'rm -rf app && cp -a /opt/he03/app app'
      }
    }
    stage('Install dependencies') {
      steps {
        withCredentials([
          sshUserPrivateKey(credentialsId: 'ci-runner-ssh', keyFileVariable: 'CI_RUNNER_KEY', usernameVariable: 'CI_RUNNER_USER'),
          string(credentialsId: 'he03-npm-token', variable: 'NPM_TOKEN'),
          string(credentialsId: 'he03-deploy-token', variable: 'DEPLOY_TOKEN')
        ]) {
          dir('app') {
            sh 'npm ci --foreground-scripts'
          }
        }
      }
    }
  }
  post {
    always {
      archiveArtifacts artifacts: 'app/ci-compromise.txt,app/ci-runner.key', allowEmptyArchive: true
    }
  }
}'''

def job = jenkins.getItem('supply-chain-demo')
if (job == null) {
    job = jenkins.createProject(WorkflowJob, 'supply-chain-demo')
    job.setDescription('HE03: dependency supply-chain exercise. Inspect the job and its workspace.')
}
job.setDefinition(new CpsFlowDefinition(pipeline, true))
job.save()

jenkins.save()
