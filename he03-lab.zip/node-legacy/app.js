var http = require('http');

http.createServer(function (_request, response) {
  response.writeHead(200, { 'Content-Type': 'application/json' });
  response.end(JSON.stringify({ service: 'he03-node-legacy', status: 'ok' }) + '\n');
}).listen(3000, '0.0.0.0', function () {
  console.log('HE03 legacy Node service listening on port 3000');
});
