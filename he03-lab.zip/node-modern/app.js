const http = require('http');

http.createServer((_request, response) => {
  response.writeHead(200, { 'Content-Type': 'application/json' });
  response.end(`${JSON.stringify({ service: 'he03-node-modern', status: 'ok' })}\n`);
}).listen(3000, '0.0.0.0', () => {
  console.log('HE03 modern Node service listening on port 3000');
});
